-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Client :  127.0.0.1
-- Généré le :  Dim 01 Mai 2016 à 11:19
-- Version du serveur :  5.6.26
-- Version de PHP :  5.6.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `symfony`
--

-- --------------------------------------------------------

--
-- Structure de la table `article`
--

CREATE TABLE IF NOT EXISTS `article` (
  `id` int(11) NOT NULL,
  `Nom` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `Prix` double NOT NULL,
  `quantite` double NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `categories_id` int(11) NOT NULL,
  `image_id` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `article`
--

INSERT INTO `article` (`id`, `Nom`, `description`, `Prix`, `quantite`, `token`, `categories_id`, `image_id`) VALUES
(2, 'J''adore', 'François Demachy voulait accentuer le caractère lumineux de l’eau de toilette J’adore. Il a ainsi choisi de souligner ses contrastes, de moduler ses facettes, de respecter sa signature florale tout renouvelant sa fraîcheur. Une volonté de lui donner enco', 103, 20, 'qfjmxvwwvr44scs0wo0o8s4sg0s8oc8', 6, 2),
(3, 'Miss Dior', '« Pour qu''un parfum tienne, il faut d''abord qu''il ait tenu longtemps au coeur de ceux qui l''ont créé. » Miss Dior est la fragrance de coeur de Monsieur Dior, celle qu’il a chéri longuement avant de la dévoiler. Le parfum de l’audace, du renouveau et de l', 94, 30, 'b1gaa7x4ocw8go4gk8cgwgcckwoswog', 6, 3),
(4, 'poison', 'Poison Girl est le parfum d''une fille d''aujourd''hui, libre et sexy. Un piège délicieux, qui empoisonne instantanément et fait durer le plaisir jusqu''à l''addiction. Poison Girl s’annonce d’emblée, addictif et ravageur. Un effet cash, immédiat.', 94, 25, 'j233d5kdi60wswccwoc08ws8ok0w0cg', 6, 4),
(6, 'Trésor', 'LE PARFUMS DES INSTANTS PRÉCIEUX Trésor est le parfum de l''amour absolu. Une fragrance radieuse aux notes de rose encapsulée dans un trésor de cristal.', 54, 50, '7qv254f5u2888wgw40ks0skg4kgc48', 7, 6),
(7, 'La vie est belle', 'La vie est belle est une déclaration universelle au bonheur. Un bouquet floral gourmand encapsulé dans un sourire. FEMME La Vie est Belle', 60, 56, 'lq44mkomwr4ckk0oo8cgskssk4o0kk0', 7, 7);

-- --------------------------------------------------------

--
-- Structure de la table `article1`
--

CREATE TABLE IF NOT EXISTS `article1` (
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `categorie`
--

CREATE TABLE IF NOT EXISTS `categorie` (
  `id` int(11) NOT NULL,
  `nom` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `categorie`
--

INSERT INTO `categorie` (`id`, `nom`, `description`, `token`, `status`) VALUES
(6, 'Dior', 'Apporter à la femme une nouvelle élégance : tel était le désir de Christian Dior. C''est ainsi qu''il lui dessine des robes, lui crée des parfums', 'jhbw1jmbhuoggwc0scg0wg00k0w4k88', 0),
(7, 'lancôme', 'Lancôme est une maison de cosmétiques et de produits de luxe créée le 21 février 1935 par Armand Petitjean, parfumeur à Paris. Le nom est choisi pour sa sonorité « bien française »', '8fdd7tdlb6sk0kkg8o8kogso04s8088', 1);

-- --------------------------------------------------------

--
-- Structure de la table `image`
--

CREATE TABLE IF NOT EXISTS `image` (
  `id` int(11) NOT NULL,
  `url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `alt` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `image`
--

INSERT INTO `image` (`id`, `url`, `alt`) VALUES
(1, 'jpeg', 12049143),
(2, 'jpeg', 0),
(3, 'jpeg', 0),
(4, 'jpeg', 0),
(5, 'jpeg', 2147483647),
(6, 'jpeg', 0),
(7, 'jpeg', 2147483647);

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `username_canonical` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email_canonical` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  `salt` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `locked` tinyint(1) NOT NULL,
  `expired` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  `confirmation_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password_requested_at` datetime DEFAULT NULL,
  `roles` longtext COLLATE utf8_unicode_ci NOT NULL COMMENT '(DC2Type:array)',
  `credentials_expired` tinyint(1) NOT NULL,
  `credentials_expire_at` datetime DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `user`
--

INSERT INTO `user` (`id`, `username`, `username_canonical`, `email`, `email_canonical`, `enabled`, `salt`, `password`, `last_login`, `locked`, `expired`, `expires_at`, `confirmation_token`, `password_requested_at`, `roles`, `credentials_expired`, `credentials_expire_at`) VALUES
(1, 'Sabrine', 'sabrine', 'benmahmousabk@gmail.com', 'benmahmousabk@gmail.com', 1, '8fyg58gzw5k4gwwwgsgskwoosskgw0s', 'KN7CFO+BSLtkiQLhhyUgBohOBNyUFQZMEHrVA7bgv6nFxP3C66zDaNg4oGnPSYh1VAdwKqCSOSlyAfXGB+SWpQ==', NULL, 0, 0, NULL, NULL, NULL, 'a:0:{}', 0, NULL),
(2, 'admin', 'admin', 'admin@hotmail.fr', 'admin@hotmail.fr', 1, '4f52y2ojhickw4ogkkw8sccowow8ocw', '3F8YbQPgav2l16tq152h5DZWU2tMlV/sP3MtpMU8kPHmwQQDCIOkaY7WIzG/VrvnSjOcA4GF3WQA29DRhnafXw==', NULL, 0, 0, NULL, NULL, NULL, 'a:0:{}', 0, NULL),
(3, 'Sab', 'sab', 'sab@hotmail.com', 'sab@hotmail.com', 1, 'jcd1eo20w4oogwocwksok0cw4sgogok', 'PbpRaRy0NPzS6MQbmgrTkqymLNDJsfrTMl10FSi4EMmbHkYL8qVKQj5/bk5e3yGbS/L1mvHWbL8tRSiAkCZs2Q==', NULL, 0, 0, NULL, NULL, NULL, 'a:0:{}', 0, NULL),
(4, 'houssem', 'houssem', 'selmi_houssem@hotmail.fr', 'selmi_houssem@hotmail.fr', 1, 'jwqo3wj3j74soc0s44skco8o4s00sw0', 'Hfs80R9Il1ORDUh7NMbWL/OyJ7fNz1dOLR7TsQaTwQ5tUt0WW2gVlKAA+B1VFdNk2iPxC7q18mxWdH56KJxDLg==', '2015-10-18 12:56:14', 0, 0, NULL, NULL, NULL, 'a:0:{}', 0, NULL),
(5, 'jhkjhj', 'jhkjhj', 'jhkjh@hhh.fr', 'jhkjh@hhh.fr', 1, 'nj3c8b315tco0w8swc00skco00o88sw', '58e6Tf1RFW2dSH/E0nPjDpaYYhoOspRNRtT99W2qH2utGeyvQeC3Vk1CgMbn7/89/7Kgm+QAAzXNFefsiRzudg==', '2015-10-18 13:05:03', 0, 0, NULL, NULL, NULL, 'a:0:{}', 0, NULL);

--
-- Index pour les tables exportées
--

--
-- Index pour la table `article`
--
ALTER TABLE `article`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_CD8737FA3DA5256D` (`image_id`),
  ADD KEY `IDX_CD8737FAA21214B7` (`categories_id`);

--
-- Index pour la table `article1`
--
ALTER TABLE `article1`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `categorie`
--
ALTER TABLE `categorie`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `image`
--
ALTER TABLE `image`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_2DA1797792FC23A8` (`username_canonical`),
  ADD UNIQUE KEY `UNIQ_2DA17977A0D96FBF` (`email_canonical`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `article`
--
ALTER TABLE `article`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT pour la table `article1`
--
ALTER TABLE `article1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `categorie`
--
ALTER TABLE `categorie`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT pour la table `image`
--
ALTER TABLE `image`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT pour la table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `article`
--
ALTER TABLE `article`
  ADD CONSTRAINT `FK_CD8737FA3DA5256D` FOREIGN KEY (`image_id`) REFERENCES `image` (`id`),
  ADD CONSTRAINT `FK_CD8737FAA21214B7` FOREIGN KEY (`categories_id`) REFERENCES `categorie` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
